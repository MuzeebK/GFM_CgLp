function m = cep_stepm(d, P0, P1, tstep)
%CEP_STEPM  Metrics of a power-reference step from a simulation log.
t = d(:,1); pf = d(:,9); f = d(:,3)/(2*pi); k = t >= tstep; dy = P1 - P0;
tk = t(k); yk = pf(k);
m.os   = max(0, (max(yk) - P1)/dy*100);
out = find(abs(yk - P1) > 0.02*abs(dy));
if isempty(out), m.ts = 0; else, m.ts = tk(out(end)) - tstep; end
m.itae = trapz(tk - tstep, (tk - tstep).*abs(yk - P1));
m.fpk  = max(f(k)) - 50;
m.pmax = max(d(k,2));  m.imax = max(d(k,5));  m.nres = d(end,10);
r = find(diff(d(:,10)) > 0 & t(1:end-1) >= tstep, 1);
if isempty(r)
    m.tres = NaN; m.fbef = NaN; m.faft = NaN; m.pfres = NaN;
else
    m.tres = t(r+1); m.fbef = f(r); m.faft = f(r+1); m.pfres = pf(r);
end
end
