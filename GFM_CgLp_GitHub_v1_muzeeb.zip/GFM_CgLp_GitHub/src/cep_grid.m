function [vg, thg] = cep_grid(t, Vf, tf0, tf1, phi, tj, Vn)
%CEP_GRID  Grid voltage (alpha-beta, pu): positive sequence with optional
%   voltage dip [tf0, tf1) to Vf, phase jump phi at tj, and negative
%   sequence of magnitude Vn.
%#codegen
wb = 2*pi*50;
V = 1.0; if t >= tf0 && t < tf1, V = Vf; end
thg = wb*t; if t >= tj, thg = thg + phi; end
vg = [V*cos(thg) + Vn*cos(-thg); V*sin(thg) + Vn*sin(-thg)];
end
