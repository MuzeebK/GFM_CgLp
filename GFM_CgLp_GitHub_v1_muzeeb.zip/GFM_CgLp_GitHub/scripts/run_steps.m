%RUN_STEPS  Power-reference steps 0.6 -> 0.8 pu versus SCR (Simulink)
%   Droop, lead a = 3, lead a = 4.6, CgLp and CgLp with reset disabled.
%   Paper: Figs. 5-6, Table 5 and the reset ablation. Output:
%   results/R_steps.txt and results/steps.mat.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'), fullfile(root,'model'));
rdir = fullfile(root,'results'); if ~exist(rdir,'dir'), mkdir(rdir); end
D = {'droop','lead3','lead46','cglp','cglp_off'}; S = [2 5 10 20 30];
ev = cep_ev('P0',0.6,'P1',0.8,'tstep',0.3);
fid = fopen(fullfile(rdir,'R_steps.txt'),'w'); M = struct(); TR = struct();
for s = S
    for j = 1:numel(D)
        d = cep_sim(s, cep_design(D{j}), ev, 2.3, 10);
        m = cep_stepm(d, 0.6, 0.8, 0.3); key = sprintf('%s_%d', D{j}, s); M.(key) = m;
        cep_log(fid,'SCR %2d %-9s OS %6.2f %% ts %6.3f s ITAE %.5f fpk %.4f Hz pmax %.4f imax %.4f nres %d tres %.4f fbef %.4f faft %.4f pfres %.4f\n', ...
            s, D{j}, m.os, m.ts, m.itae, m.fpk, m.pmax, m.imax, m.nres, m.tres, m.fbef, m.faft, m.pfres);
        if s == 20 || s == 2, TR.(key) = d; end
    end
end
fclose(fid);
save(fullfile(rdir,'steps.mat'),'M','TR','D','S');
disp('run_steps done');
