function cp = cep_design(name, varargin)
%CEP_DESIGN  Parameter vector of the outer-loop compensator.
%   cp = [ctype wz wp wra gamma wr wt band wf notchQ sigma seed]
%   names: 'droop', 'lead3', 'lead46', 'lead' (ratio a), 'cglp',
%          'cglp_off' (gamma = 1), 'cglp_gen' (kr, kt, gamma [, band]).
p = cep_params(20); wc = 21.3; cp = zeros(1,12); cp(9) = p.wf;
switch lower(name)
    case 'droop'
    case 'lead3',  cp(1) = 1; cp(2:3) = p.lead3;
    case 'lead46', cp(1) = 1; cp(2:3) = p.lead46;
    case 'lead',   a = varargin{1}; cp(1) = 1; cp(2:3) = [25.6/sqrt(a) 25.6*sqrt(a)];
    case {'cglp','cglp_off','cglp_gen'}
        kr = 0.7; kt = 10; g = 0; band = 0.02;
        if strcmpi(name,'cglp_gen')
            kr = varargin{1}; kt = varargin{2}; g = varargin{3};
            if numel(varargin) > 3, band = varargin{4}; end
        end
        th = 4*(1-g)/(pi*(1+g)); al = sqrt(1+th^2); wr = kr*wc;
        cp(1) = 2; cp(4) = wr/al; cp(5) = g; cp(6) = wr; cp(7) = kt*wc; cp(8) = band;
        if strcmpi(name,'cglp_off'), cp(5) = 1; end
    otherwise
        error('cep_design: unknown design %s', name);
end
end
