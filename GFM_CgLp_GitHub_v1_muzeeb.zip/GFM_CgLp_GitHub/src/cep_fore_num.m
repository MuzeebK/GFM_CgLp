function [N, t, y, e] = cep_fore_num(w, wra, g, ncyc, npc)
%CEP_FORE_NUM  First harmonic of a FORE driven by sin(w t), from a
%   time-domain simulation (exact flow, trapezoidal input hold, reset at
%   the zero crossings of the input).
if nargin < 4, ncyc = 40; end
if nargin < 5, npc = 4000; end
dt = 2*pi/w/npc; a = exp(-wra*dt); x = 0; n = ncyc*npc;
y = zeros(n,1); e = zeros(n,1); t = (1:n)'*dt; ep = 0;
for k = 1:n
    e2 = sin(w*t(k)); x = a*x + (1-a)*0.5*(ep + e2);
    if ep*e2 < 0, x = g*x; end
    y(k) = x; e(k) = e2; ep = e2;
end
m = min(npc*10, n); yy = y(end-m+1:end); tt = t(end-m+1:end);
N = 2*mean(yy.*exp(-1j*w*tt))/(-1j);
end
