%RUN_NOISE_UNBALANCE  Measurement noise, unbalanced grid and the
%   overshoot-jitter trade-off at SCR 20 (Simulink).
%   Paper: Section 5.4, Table 6, Figs. 7-8. Output: results/R_hf.txt and
%   results/hf.mat.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'), fullfile(root,'model'));
rdir = fullfile(root,'results'); if ~exist(rdir,'dir'), mkdir(rdir); end
D = {'droop','lead3','lead46','cglp'};
fid = fopen(fullfile(rdir,'R_hf.txt'),'w');
% ---------------------------------------------------------- noise
NZ = struct();
for j = 1:numel(D)
    r = zeros(5,3);
    for s = 1:5
        cp = cep_design(D{j}); cp(11) = 0.02; cp(12) = s;
        d = cep_sim(20, cp, cep_ev(), 3.0, 25); [r(s,:), dd] = noisem(d);
        if s == 1, NZ.(D{j}) = dd; end
    end
    cep_log(fid,'NOISE %-7s frms %.3f +- %.3f mHz  drms %.4f deg  resets/s %.2f (min %.2f max %.2f)\n', ...
        D{j}, mean(r(:,1)), std(r(:,1)), mean(r(:,2)), mean(r(:,3)), min(r(:,3)), max(r(:,3)));
end
for s = 1:2   % ideal zero-crossing reset (no band)
    cp = cep_design('cglp_gen',0.7,10,0,0); cp(11) = 0.02; cp(12) = s;
    r = noisem(cep_sim(20, cp, cep_ev(), 3.0, 25));
    cep_log(fid,'NOISE cglp, no band, seed %d: frms %.3f mHz resets/s %.1f\n', s, r(1), r(3));
end
cp = cep_design('cglp'); d = cep_sim(20, cp, cep_ev('P0',0.6,'P1',0.8,'tstep',0.3), 2.3, 25);
cep_log(fid,'clean step check, band 0.02: OS %.2f %%\n', cep_stepm(d,0.6,0.8,0.3).os);
d = cep_sim(20, cep_design('cglp_gen',0.7,10,0,0), cep_ev('P0',0.6,'P1',0.8,'tstep',0.3), 2.3, 25);
cep_log(fid,'clean step check, no band:   OS %.2f %%\n', cep_stepm(d,0.6,0.8,0.3).os);
% ------------------------------------------------------- unbalance
UB = struct();
for j = 1:numel(D)
    for q = [0 2]
        cp = cep_design(D{j}); cp(10) = q;
        d = cep_sim(20, cp, cep_ev('P0',0.6,'P1',0.8,'tstep',1.5,'Vn',0.05), 3.0, 5);
        t = d(:,1); k = t > 1.0 & t < 1.5; f = d(k,3)/(2*pi); pp = d(k,2);
        n = round(0.02/(t(2)-t(1))); ys = movmean(d(:,9), n); kk = t >= 1.5 & t < 2.95;
        os = max(0, (max(ys(kk)) - 0.8)/0.2*100);
        nr = d(:,10); rps = (nr(find(t>=1.5,1)) - nr(find(t>=1.0,1)))/0.5;
        cep_log(fid,'UNBAL %-7s notchQ %d: f ripple %.3f mHz p-p, p ripple %.3f pu p-p, step OS %.2f %%, resets/s %.1f\n', ...
            D{j}, q, (max(f)-min(f))*1000, max(pp)-min(pp), os, rps);
    end
    cp = cep_design(D{j}); cp(10) = 2;
    UB.(D{j}) = cep_sim(20, cp, cep_ev('P0',0.6,'P1',0.8,'tstep',0.5,'Vn',0.05), 1.5, 10);
end
% ------------------------------------------------------- trade-off
PA = [];
for a = [1.5 2 3 4.6 6], PA = [PA; 1 a tradeoff(cep_design('lead',a))]; end %#ok<AGROW>
for k = [1 1.5 2 3 4]
    cp = cep_design('droop'); cp(9) = k*2*pi*2; PA = [PA; 0 k tradeoff(cp)]; %#ok<AGROW>
end
for kr = [0.5 0.6 0.7 0.85 1.0], PA = [PA; 2 kr tradeoff(cep_design('cglp_gen',kr,10,0))]; end %#ok<AGROW>
for i = 1:size(PA,1), cep_log(fid,'PARETO kind %d par %.2f OS %.2f %% frms %.3f mHz\n', PA(i,:)); end
fclose(fid);
save(fullfile(rdir,'hf.mat'),'NZ','UB','PA');
disp('run_noise_unbalance done');

function [r, d] = noisem(d)
t = d(:,1); m = t > 0.5; f = d(m,3)/(2*pi); dl = d(m,4)*180/pi;
nr = d(:,10); r = [std(f-50)*1000, std(dl - mean(dl)), (nr(end) - nr(find(m,1)))/2.5];
end
function v = tradeoff(cp)
m = cep_stepm(cep_sim(20, cp, cep_ev('P0',0.6,'P1',0.8,'tstep',0.3), 2.3, 25), 0.6, 0.8, 0.3);
fr = zeros(1,3);
for s = 1:3
    c2 = cp; c2(11) = 0.02; c2(12) = s; d = cep_sim(20, c2, cep_ev(), 3.0, 25);
    t = d(:,1); k = t > 0.5; fr(s) = std(d(k,3)/(2*pi) - 50)*1000;
end
v = [m.os mean(fr)];
end
