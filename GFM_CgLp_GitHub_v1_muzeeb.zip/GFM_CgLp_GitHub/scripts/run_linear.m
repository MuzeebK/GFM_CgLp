%RUN_LINEAR  Small-signal and describing-function results
%   Droop modes, compensator responses, FORE describing function check,
%   phase margins versus SCR, network resonance and the H_beta condition.
%   Paper: Figs. 2-4, Tables 3 and 6. Output: results/R_linear.txt and
%   results/linear.mat.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'), fullfile(root,'model'));
rdir = fullfile(root,'results'); if ~exist(rdir,'dir'), mkdir(rdir); end
fid = fopen(fullfile(rdir,'R_linear.txt'),'w');
p20 = cep_params(20); c = cep_design('cglp'); wc = 21.3;
% ---------------------------------------------------------- droop modes
cep_log(fid,'--- droop closed-loop modes (zeta, f in Hz) ---\n');
for scr = [1.5 2 5 10 20 30 50]
    [A,B,C,x0] = cep_linear(scr); ev = eig(A - B*C); ev = ev(imag(ev) > 1e-3);
    [~,i] = sort(abs(imag(ev))); ev = ev(i);
    cep_log(fid,'SCR %4.1f delta0 %6.2f deg :', scr, x0(3)*180/pi);
    cep_log(fid,' (%.3f, %.2f Hz)', [-real(ev)./abs(ev) abs(imag(ev))/2/pi].');
    cep_log(fid,'\n');
end
% ------------------------------------------------ compensator responses
CL = @(w) (1+1j*w/c(6))./(1+1j*w/c(7));
ld = @(w,z,p) (1+1j*w/z)./(1+1j*w/p);
Cf = {@(w) ones(size(w)), @(w) ld(w,p20.lead3(1),p20.lead3(2)), ...
      @(w) ld(w,p20.lead46(1),p20.lead46(2)), @(w) cep_fore_df(w,c(4),c(5)).*CL(w)};
nm = {'Droop','Lead3','Lead46','CgLp'};
cep_log(fid,'--- compensator first-harmonic response ---\n');
for j = 1:4
    for wq = [wc 2*pi*50 2*pi*100]
        z = Cf{j}(wq);
        cep_log(fid,'%-7s w=%7.2f |C|=%.3f (%6.2f dB) ang=%6.2f deg\n', nm{j}, wq, abs(z), 20*log10(abs(z)), angle(z)*180/pi);
    end
end
wq = logspace(0,3,3000); z = Cf{4}(wq); [phm,k] = max(angle(z)*180/pi);
cep_log(fid,'CgLp peak phase %.2f deg at %.1f rad/s\n', phm, wq(k));
% --------------------------------- describing function, time-domain check
cep_log(fid,'--- FORE DF: analytic vs time domain (wra = 1) ---\n');
emax = [0 0];
for g = [-0.2 0 0.3]
    for w = [0.5 1 2 5 10 20]
        Na = cep_fore_df(w,1,g); Nn = cep_fore_num(w,1,g);
        dph = abs(angle(Nn) - angle(Na))*180/pi; dm = abs(abs(Nn)/abs(Na) - 1)*100;
        emax = max(emax, [dph dm]);
        cep_log(fid,'g=%5.2f w=%5.1f analytic %.4f<%7.3f  numeric %.4f<%7.3f\n', g, w, abs(Na), angle(Na)*180/pi, abs(Nn), angle(Nn)*180/pi);
    end
end
cep_log(fid,'max phase error %.4f deg, max magnitude error %.4f %%\n', emax);
% ------------------------------------------------------------ loop gains
w = logspace(-0.5,3.5,4000);
scrs = [1.5 2 3 5 7 10 15 20 25 30 40 50]; PM = zeros(numel(scrs),4); WC = PM;
for i = 1:numel(scrs)
    [A,B,C] = cep_linear(scrs(i)); G = squeeze(freqresp(ss(A,B,C,0), w)).';
    for j = 1:4
        [WC(i,j), PM(i,j)] = pmargin(w, Cf{j}(w).*G);
    end
    cep_log(fid,'SCR %4.1f PM: droop %5.1f lead3 %5.1f lead46 %5.1f CgLp %5.1f | wc droop %5.2f\n', scrs(i), PM(i,:), WC(i,1));
end
[A,B,C] = cep_linear(20); G20 = squeeze(freqresp(ss(A,B,C,0), w)).';
kk = find(w > 150 & w < 600); ir = find(islocalmax(abs(G20(kk))),1); wres = w(kk(ir));
cep_log(fid,'network resonance at %.1f rad/s; loop gain there (dB):', wres);
for j = 1:4, cep_log(fid,' %s %.1f', nm{j}, 20*log10(abs(Cf{j}(wres)*G20(kk(ir))))); end
cep_log(fid,'\n');
% ---------------------------------------------------------------- H_beta
cep_log(fid,'--- H_beta (LMI Lab) ---\n');
wh = logspace(-3,5,20000);
for scr = [1.5 2 3 5 10 15 20 30 50]
    [ok,b,r,tmin,Acl,Cp] = cep_hbeta(scr); N = size(Acl,1); B0 = [zeros(N-1,1); 1];
    H = zeros(size(wh));
    for q = 1:numel(wh), H(q) = [b*Cp r]*((1j*wh(q)*eye(N) - Acl)\B0); end
    Hinf = 1e6^2*real([b*Cp r]*((1j*1e6*eye(N) - Acl)\B0));
    cep_log(fid,'SCR %4.1f maxRe(Acl) %.3f feasible %d tmin %.3e beta %.4e rho %.4e minRe(Hb) %.3e w2ReHb(1e6) %.3e\n', ...
        scr, max(real(eig(Acl))), ok, tmin, b, r, min(real(H)), Hinf);
end
fclose(fid);
% ------------------------------------------------- data for Figs. 2 to 4
[~,t2,y0,e2] = cep_fore_num(1,1,0,6,2000); [~,~,y1] = cep_fore_num(1,1,1,6,2000);
k2 = t2 > 4*pi;
F2.t = t2(k2) - 4*pi; F2.v = e2(k2); F2.fore = y0(k2); F2.linear = y1(k2);
F2.w = logspace(-1.3,1.6,400); F2.gam = [0 0.3 0.6];
F2.ph = zeros(numel(F2.gam),numel(F2.w));
for q = 1:numel(F2.gam), F2.ph(q,:) = angle(cep_fore_df(F2.w,1,F2.gam(q)))*180/pi; end
F2.ph_lin = angle(1./(1j*F2.w+1))*180/pi;
F3.w = logspace(-0.3,3.4,1500); F3.C = zeros(4,numel(F3.w));
for j = 1:4, F3.C(j,:) = Cf{j}(F3.w); end
F3.wn = [3 10 21.3 60 200 628]; F3.Cn = zeros(size(F3.wn));
for q = 1:numel(F3.wn), F3.Cn(q) = cep_fore_num(F3.wn(q),c(4),c(5))*CL(F3.wn(q)); end
F4.w = w; F4.L = zeros(4,numel(w));
for j = 1:4, F4.L(j,:) = Cf{j}(w).*G20; end
save(fullfile(rdir,'linear.mat'),'PM','WC','scrs','wres','nm','F2','F3','F4');
disp('run_linear done');

function [wc,pm] = pmargin(w,L)
% crossover frequency and phase margin by log-linear interpolation
m = abs(L); k = find(m(1:end-1) >= 1 & m(2:end) < 1, 1);
f = log(m(k))/(log(m(k)) - log(m(k+1)));
wc = exp(log(w(k)) + f*(log(w(k+1)) - log(w(k))));
ph = unwrap(angle(L)); pm = 180 + (ph(k) + f*(ph(k+1) - ph(k)))*180/pi;
end
