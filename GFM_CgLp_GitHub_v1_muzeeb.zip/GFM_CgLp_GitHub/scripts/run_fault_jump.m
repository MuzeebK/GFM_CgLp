%RUN_FAULT_JUMP  120 ms bolted dip at SCR 10 and 30 deg grid phase jump
%   at SCR 20 (Simulink). The CgLp with reset disabled is also run for
%   6 s to find when it leaves current limiting.
%   Paper: Figs. 9 and 11, Sections 5.5-5.6. Output: results/R_fault.txt
%   and results/fault.mat.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'), fullfile(root,'model'));
rdir = fullfile(root,'results'); if ~exist(rdir,'dir'), mkdir(rdir); end
D = {'droop','lead3','lead46','cglp','cglp_off'};
evf = cep_ev('Vf',0,'tf0',0.5,'tf1',0.62);
fid = fopen(fullfile(rdir,'R_fault.txt'),'w'); FT = struct(); JP = struct();
for j = 1:numel(D)
    d = cep_sim(10, cep_design(D{j}), evf, 3.0, 10);
    FT.(D{j}) = d; t = d(:,1); f = d(:,3)/(2*pi);
    islip = find(abs(d(:,4)) > pi, 1); tslip = NaN; if ~isempty(islip), tslip = t(islip); end
    kpost = find(t >= 0.62); r = find(diff(d(:,10)) > 0); r = r(t(r+1) >= 0.62);
    if isempty(r), tr = NaN; fb = NaN; fa = NaN; else, r = r(1); tr = t(r+1); fb = f(r); fa = f(r+1); end
    ilim = find(d(:,5) > 1.0 & t >= 0.62); tlim = NaN; if ~isempty(ilim), tlim = t(ilim(end)); end
    cep_log(fid,'FAULT %-9s max|delta| %.3f rad  slip at %.3f s  first reset after clearing %.4f s (f %.4f -> %.4f Hz)  last |i|>1 at %.3f s  f_end %.4f  p_end %.4f  max|i| %.3f  fmax %.4f\n', ...
        D{j}, max(abs(d(:,4))), tslip, tr, fb, fa, tlim, f(end), d(end,2), max(d(:,5)), max(f(kpost)));
end
d = cep_sim(10, cep_design('cglp_off'), evf, 6.0, 10); t = d(:,1);
ilim = find(d(:,5) > 1.0 & t >= 0.62);
cep_log(fid,'FAULT cglp_off (6 s run) max|delta| %.3f rad  last |i|>1 at %.3f s  f_end %.4f  p_end %.4f\n', ...
    max(abs(d(:,4))), t(ilim(end)), d(end,3)/(2*pi), d(end,2));
FT.cglp_off_6s = d;
for j = 1:4
    d = cep_sim(20, cep_design(D{j}), cep_ev('phi',pi/6,'tj',0.3), 1.5, 10);
    JP.(D{j}) = d; t = d(:,1); dl = d(:,4)*180/pi; k = t >= 0.3;
    dfin = dl(end); [dmax, im] = max(dl(k)); tk = t(k);
    out = find(abs(dl(k) - dfin) > 0.5); ts = tk(out(end)) - 0.3;
    cep_log(fid,'JUMP %-7s delta0 %.2f deg, after jump %.2f, final %.2f, max %.2f at %.3f s (overshoot %.2f), max|delta| %.2f, 0.5 deg settling %.3f s, pmax %.3f pmin %.3f\n', ...
        D{j}, dl(1), dl(find(k,1)+1), dfin, dmax, tk(im), dmax - dfin, max(abs(dl)), ts, max(d(k,2)), min(d(k,2)));
end
fclose(fid);
save(fullfile(rdir,'fault.mat'),'FT','JP');
disp('run_fault_jump done');
