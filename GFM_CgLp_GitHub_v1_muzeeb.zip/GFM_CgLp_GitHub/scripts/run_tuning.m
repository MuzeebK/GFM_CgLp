%RUN_TUNING  Grid search of the CgLp design parameters (Simulink)
%   gamma x kr x kt, power steps 0.6 -> 0.8 pu at SCR 20 and SCR 2
%   (80 runs). Paper: Section 3.3. Output: results/R_tune.txt and
%   results/tune.mat.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'), fullfile(root,'model'));
rdir = fullfile(root,'results'); if ~exist(rdir,'dir'), mkdir(rdir); end
ev = cep_ev('P0',0.6,'P1',0.8,'tstep',0.3);
fid = fopen(fullfile(rdir,'R_tune.txt'),'w'); R = [];
for g = [0 0.2 0.4 0.6]
    for kr = [0.35 0.5 0.7 1.0 1.4]
        for kt = [10 20]
            cp = cep_design('cglp_gen', kr, kt, g);
            a = cep_stepm(cep_sim(20,cp,ev,2.3,25),0.6,0.8,0.3);
            b = cep_stepm(cep_sim(2, cp,ev,2.3,25),0.6,0.8,0.3);
            R = [R; g kr kt a.os a.ts a.itae b.os b.ts b.itae]; %#ok<AGROW>
            cep_log(fid,'g %.1f kr %.2f kt %2d | SCR20 OS %6.2f ts %.3f ITAE %.5f | SCR2 OS %6.2f ts %.3f ITAE %.5f\n', R(end,:));
        end
    end
end
ok = R(:,4) < 3 & R(:,7) < 3; Rk = R(ok,:); [~,i] = min(Rk(:,6));
cep_log(fid,'best (OS<3%% at both SCR, min ITAE at SCR20): g %.1f kr %.2f kt %d\n', Rk(i,1:3));
fclose(fid); save(fullfile(rdir,'tune.mat'),'R');
disp('run_tuning done');
