function cep_log(fid, varargin)
%CEP_LOG  fprintf to the command window and to a results file.
fprintf(varargin{:}); fprintf(fid, varargin{:});
end
