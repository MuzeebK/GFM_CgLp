function p = cep_params(scr)
%CEP_PARAMS  Per-unit parameters of the grid-forming inverter study.
%   p = cep_params(scr) returns the parameter structure for a given
%   short-circuit ratio (SCR). Base frequency 50 Hz.
if nargin < 1, scr = 20; end
p.wb   = 2*pi*50;          % base angular frequency (rad/s)
p.E0   = 1.0;  p.Vg = 1.0; % internal emf set-point, grid voltage (pu)
p.xc   = 0.10; p.rc = 0.01;% coupling reactance / resistance (pu)
p.XR   = 10;               % grid X/R ratio
p.scr  = scr;
p.X    = 0.10 + 1/scr;  p.R = 0.01 + (1/scr)/10;   % xc + xg, rc + rg (codegen-safe)
p.mp   = 0.02*2*pi*50;        % P-f droop, 2 % (rad/s per pu)
p.nq   = 0.05;             % Q-V droop, 5 %
p.wf   = 2*pi*2;           % power low-pass filter (rad/s)
p.Pref = 0.8;  p.Qref = 0;
% virtual-impedance current limiter
p.Ith = 1.0; p.kR = 1.5; p.sig = 1.0; p.wI = 1/1e-3;
% compensators
wc = 21.3;                       % baseline crossover at SCR 20 (rad/s)
p.lead3  = [25.6/sqrt(3),   25.6*sqrt(3)];    % [wz wp]
p.lead46 = [25.6/sqrt(4.6), 25.6*sqrt(4.6)];
g = 0.0; th = 4*(1-g)/(pi*(1+g)); alpha = sqrt(1+th^2);
wr = 0.7*wc;
p.cglp = struct('wra', wr/alpha, 'gamma', g, 'wr', wr, 'wt', 10*wc, 'band', 0.02);
p.Ts = 1e-4;                     % controller sample time (10 kHz)
end
