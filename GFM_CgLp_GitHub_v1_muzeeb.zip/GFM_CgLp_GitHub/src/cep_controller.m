function [w, E, Rv, Xv, xr, pf, nres] = cep_controller(p_meas, q_meas, imag, t, cp, scr, P0, P1, tstep, Q0, I0)
%CEP_CONTROLLER  Discrete-time (Ts = 100 us) outer-loop controller of the
%   grid-forming inverter, called from a MATLAB Function block.
%   cp = [ctype wz wp wra gamma wr wt band wf notchQ sigma seed]
%     ctype 0: droop, 1: lead (wz, wp), 2: CgLp = lead (wr, wt) -> FORE (wra, gamma)
%     band   : reset band (0 = ideal zero-crossing reset)
%     wf     : power low-pass corner (rad/s)
%     notchQ : quality factor of a 2*wb notch on the measured power (0 = off)
%     sigma  : std of white measurement noise added to p (pu), seed: noise seed
%#codegen
persistent pfs qfs zl zr z2 If vprev armed nr ns1 ns2 rs init
p  = cep_params(scr); Ts = p.Ts;
wf = cp(9); nQ = cp(10); sig = cp(11);
% ---- 2*wb notch, bilinear transform with pre-warping ----------------------
wn = 2*p.wb; K = wn/tan(wn*Ts/2);
if nQ > 0
    a0 = K^2 + K*wn/nQ + wn^2;
    b0 = (K^2 + wn^2)/a0; b1 = 2*(wn^2 - K^2)/a0; b2 = b0;
    a1 = 2*(wn^2 - K^2)/a0; a2 = (K^2 - K*wn/nQ + wn^2)/a0;
else
    b0 = 1; b1 = 0; b2 = 0; a1 = 0; a2 = 0;
end
if isempty(init)
    pfs = P0; qfs = Q0; zl = 0; zr = 0; z2 = 0; If = I0; vprev = 0;
    armed = true; nr = 0;
    ns2 = (b2 - a2)*P0; ns1 = (b1 - a1)*P0 + ns2;
    rs  = 1 + mod(round(cp(12))*7919 + 12345, 2147483646);
    init = 1;
end
Pref = P0; if t >= tstep, Pref = P1; end
% ---- measurement: noise and notch -----------------------------------------
pm = p_meas;
if sig > 0   % Park-Miller generator + Box-Muller (deterministic, codegen-safe)
    rs = mod(16807*rs, 2147483647); u1 = rs/2147483647;
    rs = mod(16807*rs, 2147483647); u2 = rs/2147483647;
    pm = pm + sig*sqrt(-2*log(u1))*cos(2*pi*u2);
end
if nQ > 0
    y = b0*pm + ns1; ns1 = b1*pm - a1*y + ns2; ns2 = b2*pm - a2*y; pm = y;
end
af  = exp(-wf*Ts);
pfs = af*pfs + (1-af)*pm;  qfs = af*qfs + (1-af)*q_meas;
aI  = exp(-p.wI*Ts); If = aI*If + (1-aI)*imag;
e   = Pref - pfs;
% ---- compensator -----------------------------------------------------------
ct = cp(1);
if ct == 0
    u = e;
elseif ct == 1
    a = cp(3)/cp(2); al = exp(-cp(3)*Ts);
    u = a*e + (1-a)*zl;  zl = al*zl + (1-al)*e;
else
    g = cp(5); band = cp(8);
    a = cp(7)/cp(6); at = exp(-cp(7)*Ts);
    v  = a*e + (1-a)*z2;  z2 = at*z2 + (1-at)*e;      % shaping lead
    ar = exp(-cp(4)*Ts);  zr = ar*zr + (1-ar)*v;      % FORE flow
    if band <= 0 || abs(v) > band, armed = true; end
    if v*vprev < 0 && armed && g < 1                  % FORE jump
        zr = g*zr; nr = nr + 1; armed = false;
    end
    vprev = v;  u = zr;
end
w  = p.wb + p.mp*u;
E  = p.E0 + p.nq*(p.Qref - qfs);
Rv = 0; if If > p.Ith, Rv = p.kR*(If - p.Ith); end
Xv = p.sig*Rv;
xr = zr; pf = pfs; nres = nr;
end
