%MAKE_FIGURES  Plots Figs. 2-11 of the paper from the saved results
%   Run the experiment scripts first (or run_all). The figures are written
%   as PNG files to ./figures. Fig. 1 and Fig. 2(a) are block diagrams and
%   are not produced here.
root = fileparts(fileparts(mfilename('fullpath')));
rdir = fullfile(root,'results'); fdir = fullfile(root,'figures');
if ~exist(fdir,'dir'), mkdir(fdir); end
col = struct('droop',[0 0 0], 'lead3',[0.00 0.45 0.74], 'lead46',[0.47 0.67 0.19], ...
             'cglp',[0.85 0.33 0.10], 'cglp_off',[0.49 0.18 0.56]);
lbl = struct('droop','Droop', 'lead3','Lead a = 3', 'lead46','Lead a = 4.6', ...
             'cglp','CgLp', 'cglp_off','CgLp, reset off');
set(groot,'defaultAxesFontName','Times New Roman','defaultAxesFontSize',9, ...
    'defaultTextFontName','Times New Roman','defaultLineLineWidth',1.1, ...
    'defaultAxesBox','on','defaultAxesXGrid','on','defaultAxesYGrid','on');
L = load(fullfile(rdir,'linear.mat'));
% ------------------------------------------------------------------ Fig. 2
fg = figure('Units','centimeters','Position',[2 2 17 6.5]);
subplot(1,2,1); F = L.F2;
plot(F.t, F.v, 'Color',[0.6 0.6 0.6]); hold on
plot(F.t, F.linear, 'k'); plot(F.t, F.fore, 'Color',col.cglp, 'LineWidth',1.4);
xlim([0 4*pi]); ylim([-1.15 1.15]); xticks(0:pi:4*pi);
xticklabels({'0','\pi','2\pi','3\pi','4\pi'});
xlabel('\omega_{r\alpha}t (rad)'); ylabel('Signal (pu)'); title('(b)');
legend('input v','linear filter (\gamma = 1)','FORE (\gamma = 0)','Location','southoutside','Orientation','horizontal');
subplot(1,2,2); ls = {'-','--',':'};
for q = 1:numel(F.gam)
    semilogx(F.w, F.ph(q,:), ls{q}, 'Color',col.cglp); hold on
end
semilogx(F.w, F.ph_lin, 'k'); xlim([0.05 40]); ylim([-95 0]);
xlabel('\omega/\omega_{r\alpha}'); ylabel('First-harmonic phase (deg)'); title('(c)');
legend('\gamma = 0','\gamma = 0.3','\gamma = 0.6','\gamma = 1 (linear)','Location','southoutside','Orientation','horizontal');
exportgraphics(fg, fullfile(fdir,'fig02_cglp.png'),'Resolution',300);
% ------------------------------------------------------------------ Fig. 3
F = L.F3; key = {'droop','lead3','lead46','cglp'};
fg = figure('Units','centimeters','Position',[2 2 9 10]);
subplot(2,1,1);
for j = 1:4, semilogx(F.w, 20*log10(abs(F.C(j,:))), 'Color',col.(key{j})); hold on; end
semilogx(F.wn, 20*log10(abs(F.Cn)), 'o', 'Color',col.cglp);
ylabel('Gain (dB)'); xlim([F.w(1) F.w(end)]);
legend([cellfun(@(k) lbl.(k), key, 'UniformOutput', false) {'CgLp, time domain'}],'Location','northwest');
subplot(2,1,2);
for j = 1:4, semilogx(F.w, angle(F.C(j,:))*180/pi, 'Color',col.(key{j})); hold on; end
semilogx(F.wn, angle(F.Cn)*180/pi, 'o', 'Color',col.cglp);
xlabel('\omega (rad/s)'); ylabel('Phase (deg)'); xlim([F.w(1) F.w(end)]);
exportgraphics(fg, fullfile(fdir,'fig03_df.png'),'Resolution',300);
% ------------------------------------------------------------------ Fig. 4
F = L.F4;
fg = figure('Units','centimeters','Position',[2 2 17 6.5]);
subplot(1,2,1);
for j = 1:4, semilogx(F.w, 20*log10(abs(F.L(j,:))), 'Color',col.(key{j})); hold on; end
yline(0,'k:'); xlabel('\omega (rad/s)'); ylabel('|L(j\omega)| (dB)'); title('(a) SCR 20');
xlim([1 3000]);
subplot(1,2,2);
for j = 1:4, plot(L.scrs, L.PM(:,j), '-o', 'Color',col.(key{j}), 'MarkerSize',3); hold on; end
xlabel('SCR'); ylabel('Phase margin (deg)'); title('(b)');
legend(cellfun(@(k) lbl.(k), key, 'UniformOutput', false),'Location','best');
exportgraphics(fg, fullfile(fdir,'fig04_margins.png'),'Resolution',300);
% -------------------------------------------------------------- Figs. 5-6
St = load(fullfile(rdir,'steps.mat')); key5 = {'droop','lead3','lead46','cglp','cglp_off'};
yl = {'p (pu)','p_f (pu)','\Delta f (Hz)','\delta (deg)'};
for s = [20 2]
    fg = figure('Units','centimeters','Position',[2 2 17 11]);
    for q = 1:4
        subplot(2,2,q);
        for j = 1:numel(key5)
            d = St.TR.(sprintf('%s_%d',key5{j},s)); k = d(:,1) >= 0.2 & d(:,1) <= 1.5;
            y = {d(k,2), d(k,9), d(k,3)/(2*pi) - 50, d(k,4)*180/pi};
            plot(d(k,1), y{q}, 'Color',col.(key5{j})); hold on
        end
        xlim([0.2 1.5]); xlabel('t (s)'); ylabel(yl{q}); title(sprintf('(%c)','a'+q-1));
    end
    legend(cellfun(@(k) lbl.(k), key5, 'UniformOutput', false),'Location','best');
    exportgraphics(fg, fullfile(fdir,sprintf('fig%02d_step_scr%d.png',5*(s==20)+6*(s==2),s)),'Resolution',300);
end
% ------------------------------------------------------------------ Fig. 7
H = load(fullfile(rdir,'hf.mat')); PA = H.PA;
fg = figure('Units','centimeters','Position',[2 2 9 7]);
kk = {'droop','lead3','cglp'}; nmk = {'Droop, \omega_f sweep','Lead, a sweep','CgLp, k_r sweep'};
for q = 0:2
    m = PA(:,1) == q; plot(PA(m,4), PA(m,3), '-o', 'Color',col.(kk{q+1}), 'MarkerSize',3); hold on
end
xlabel('RMS frequency jitter (mHz)'); ylabel('Overshoot at SCR 20 (%)'); legend(nmk,'Location','best');
exportgraphics(fg, fullfile(fdir,'fig07_tradeoff.png'),'Resolution',300);
% ------------------------------------------------------------------ Fig. 8
fg = figure('Units','centimeters','Position',[2 2 17 6.5]);
for j = 1:4
    d = H.NZ.(key{j}); k = d(:,1) >= 0.5 & d(:,1) <= 1.5;
    subplot(1,2,1); plot(d(k,1), (d(k,3)/(2*pi) - 50)*1000, 'Color',col.(key{j})); hold on
    d = H.UB.(key{j}); k = d(:,1) >= 0.4 & d(:,1) <= 1.4;
    subplot(1,2,2); plot(d(k,1), d(k,9), 'Color',col.(key{j})); hold on
end
subplot(1,2,1); xlabel('t (s)'); ylabel('\Delta f (mHz)'); title('(a) noise, SCR 20');
subplot(1,2,2); xlabel('t (s)'); ylabel('p_f (pu)'); title('(b) 5 % negative sequence, notch on');
legend(cellfun(@(k) lbl.(k), key, 'UniformOutput', false),'Location','best');
exportgraphics(fg, fullfile(fdir,'fig08_noise_unbal.png'),'Resolution',300);
% ------------------------------------------------------------- Figs. 9, 11
Ft = load(fullfile(rdir,'fault.mat')); key9 = {'droop','lead3','cglp','cglp_off'};
yl = {'\delta (rad)','f (Hz)','|i| (pu)','p (pu)'};
fg = figure('Units','centimeters','Position',[2 2 17 11]);
for q = 1:4
    subplot(2,2,q);
    for j = 1:numel(key9)
        d = Ft.FT.(key9{j}); k = d(:,1) >= 0.3;
        y = {d(k,4), d(k,3)/(2*pi), d(k,5), d(k,2)};
        plot(d(k,1), y{q}, 'Color',col.(key9{j})); hold on
    end
    xregion(0.5, 0.62, 'FaceColor',[0.85 0.85 0.85]);
    xlim([0.3 3]); xlabel('t (s)'); ylabel(yl{q}); title(sprintf('(%c)','a'+q-1));
end
legend(cellfun(@(k) lbl.(k), key9, 'UniformOutput', false),'Location','best');
exportgraphics(fg, fullfile(fdir,'fig09_fault.png'),'Resolution',300);
fg = figure('Units','centimeters','Position',[2 2 17 6.5]);
for j = 1:4
    d = Ft.JP.(key{j}); k = d(:,1) >= 0.25 & d(:,1) <= 1.2;
    subplot(1,2,1); plot(d(k,1), d(k,4)*180/pi, 'Color',col.(key{j})); hold on
    subplot(1,2,2); plot(d(k,1), d(k,2), 'Color',col.(key{j})); hold on
end
subplot(1,2,1); xlabel('t (s)'); ylabel('\delta (deg)'); title('(a)');
subplot(1,2,2); xlabel('t (s)'); ylabel('p (pu)'); title('(b)');
legend(cellfun(@(k) lbl.(k), key, 'UniformOutput', false),'Location','best');
exportgraphics(fg, fullfile(fdir,'fig11_jump.png'),'Resolution',300);
% ----------------------------------------------------------------- Fig. 10
C = load(fullfile(rdir,'cct.mat'));
fg = figure('Units','centimeters','Position',[2 2 17 6.5]); ttl = {'(a) dip to 0.3 pu','(b) dip to 0 pu'};
for iv = 1:2
    subplot(1,2,iv);
    for j = 1:numel(C.D)
        plot(C.S, squeeze(C.CC(iv,:,j))*1000, '-o', 'Color',col.(C.D{j}), 'MarkerSize',3); hold on
    end
    xlabel('SCR'); ylabel('CCT (ms)'); title(ttl{iv});
end
legend(cellfun(@(k) lbl.(k), C.D, 'UniformOutput', false),'Location','best');
exportgraphics(fg, fullfile(fdir,'fig10_cct.png'),'Resolution',300);
disp('make_figures done');
