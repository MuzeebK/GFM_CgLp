function N = cep_fore_df(w, wr, g)
%CEP_FORE_DF  First-harmonic describing function of a first-order reset
%   element  x' = -wr x + wr e,  x+ = g x  when e = 0  (Guo et al., 2009).
E   = exp(-pi*wr./w);  Lam = w.^2 + wr^2;
th  = 2*w.^2*(1-g).*(1+E)./(pi*Lam.*(1+g*E));
N   = wr./(1j*w+wr).*(1+1j*th);
end
