function [ok, beta, rho, tmin, Acl, Cp] = cep_hbeta(scr)
%CEP_HBETA  H_beta condition (Beker, Hollot & Chait, 2004) for the
%   CgLp-controlled power-synchronisation loop, solved with LMI Lab.
%   P = [P11 beta*Cp'; beta*Cp rho] > 0,  Acl'P + P Acl < 0.
p = cep_params(scr); c = p.cglp; a = c.wt/c.wr;
[A,B,C] = cep_linear(scr); n = size(A,1);
Ap = [A zeros(n,1); c.wt*C -c.wt]; Bp = [B;0]; Cp = [a*C 1-a];
N  = n+2;
Acl = [Ap Bp; -c.wra*Cp -c.wra];
E1 = [eye(N-1) zeros(N-1,1)]; E2 = [zeros(1,N-1) 1];
setlmis([]);
P11 = lmivar(1,[N-1 1]); be = lmivar(1,[1 0]); rh = lmivar(1,[1 0]);
lmiterm([1 1 1 P11], E1', E1*Acl, 's');
lmiterm([1 1 1 be],  E1'*Cp', E2*Acl, 's');
lmiterm([1 1 1 be],  E2', Cp*E1*Acl, 's');
lmiterm([1 1 1 rh],  E2', E2*Acl, 's');
lmiterm([-2 1 1 P11], E1', E1);
lmiterm([-2 1 1 be],  E1'*Cp', E2, 's');
lmiterm([-2 1 1 rh],  E2', E2);
lmiterm([-3 1 1 rh], 1, 1);
lmis = getlmis;
[tmin, xfeas] = feasp(lmis, [0 200 1e9 10 1]);
ok = tmin < 0;
beta = dec2mat(lmis, xfeas, be); rho = dec2mat(lmis, xfeas, rh);
end
