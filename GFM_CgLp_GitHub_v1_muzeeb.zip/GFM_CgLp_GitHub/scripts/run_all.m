%RUN_ALL  Runs every experiment of the paper and plots the figures.
%   Results are written to ./results and figures to ./figures.
%   Total run time is about 25 min on a desktop PC, most of it in the CCT
%   bisection.
here = fileparts(mfilename('fullpath'));
t0 = tic; run(fullfile(here,'run_linear.m'));          fprintf('linear: %.0f s\n', toc(t0));
t0 = tic; run(fullfile(here,'run_steps.m'));           fprintf('steps: %.0f s\n', toc(t0));
t0 = tic; run(fullfile(here,'run_fault_jump.m'));      fprintf('fault and phase jump: %.0f s\n', toc(t0));
t0 = tic; run(fullfile(here,'run_noise_unbalance.m')); fprintf('noise and unbalance: %.0f s\n', toc(t0));
t0 = tic; run(fullfile(here,'run_tuning.m'));          fprintf('tuning grid: %.0f s\n', toc(t0));
t0 = tic; run(fullfile(here,'run_cct.m'));             fprintf('CCT: %.0f s\n', toc(t0));
run(fullfile(here,'make_figures.m'));
