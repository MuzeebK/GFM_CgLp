%RUN_CCT  Critical clearing time by bisection (Simulink)
%   Balanced dips to 0.3 pu and 0 pu, SCR 2, 5, 10, 20, five controllers,
%   bisection over [0, 600] ms with 10 steps (440 runs). A dip is cleared
%   successfully when |delta| < pi throughout and f, p are within
%   0.02 Hz / 0.02 pu of 50 Hz / 0.8 pu in the last 0.3 s of a 6 s run.
%   Progress is saved after each entry, so an interrupted run resumes.
%   Paper: Table 7, Fig. 10. Output: results/R_cct.txt and results/cct.mat.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'), fullfile(root,'model'));
rdir = fullfile(root,'results'); if ~exist(rdir,'dir'), mkdir(rdir); end
D = {'droop','lead3','lead46','cglp_off','cglp'}; S = [2 5 10 20]; V = [0.3 0];
fn = fullfile(rdir,'cct.mat');
if exist(fn,'file'), load(fn,'CC'); else, CC = nan(numel(V),numel(S),numel(D)); end
for iv = 1:numel(V)
    for is = 1:numel(S)
        for j = 1:numel(D)
            if ~isnan(CC(iv,is,j)), continue; end
            cp = cep_design(D{j}); lo = 0; hi = 0.6; tic;
            if okrun(S(is), cp, V(iv), hi)
                lo = Inf;
            else
                for it = 1:10
                    mid = 0.5*(lo + hi);
                    if okrun(S(is), cp, V(iv), mid), lo = mid; else, hi = mid; end
                end
            end
            CC(iv,is,j) = lo; save(fn,'CC','D','S','V');
            fprintf('Vf %.1f SCR %2d %-9s CCT %.2f ms (%.0f s)\n', V(iv), S(is), D{j}, lo*1000, toc);
        end
    end
end
fid = fopen(fullfile(rdir,'R_cct.txt'),'w');
fprintf(fid,'# Vf SCR droop lead3 lead46 cglp_off cglp (ms)\n');
for iv = 1:numel(V)
    for is = 1:numel(S)
        fprintf(fid,'Vf %.1f SCR %2d', V(iv), S(is));
        fprintf(fid,' %.2f', squeeze(CC(iv,is,:))*1000); fprintf(fid,'\n');
    end
end
fclose(fid); type(fullfile(rdir,'R_cct.txt'));

function ok = okrun(scr, cp, Vf, tf)
T = 6.0;
d = cep_sim(scr, cp, cep_ev('Vf',Vf,'tf0',0.5,'tf1',0.5+tf), T, 200, pi);
t = d(:,1); m = t > T - 0.3;
ok = t(end) > T - 0.01 && max(abs(d(:,4))) < pi && ...
     all(abs(d(m,3)/(2*pi) - 50) < 0.02) && all(abs(d(m,2) - 0.8) < 0.02);
end
