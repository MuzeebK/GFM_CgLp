function [A,B,C,x0] = cep_linear(scr, Pref)
%CEP_LINEAR  Linearised averaged model (grid dq frame) of the droop GFM.
%   States: [id iq delta pf qf]; input u (droop channel), output pf.
p = cep_params(scr); if nargin>1, p.Pref = Pref; end
f  = @(x,u) plant(x,u,p);
g  = @(z) [f(z,0); 0];
opts = optimoptions('fsolve','Display','off','FunctionTolerance',1e-14,'StepTolerance',1e-14);
d0 = asin(min(0.9,p.Pref*p.X));
z  = fsolve(@(z) eqres(z,p), [p.Pref;0;d0;p.Pref;0], opts);
x0 = z; h = 1e-6; n = 5; A = zeros(n); B = zeros(n,1);
for k = 1:n
    dx = zeros(n,1); dx(k) = h;
    A(:,k) = (f(x0+dx,0)-f(x0-dx,0))/(2*h);
end
B(:,1) = (f(x0,h)-f(x0,-h))/(2*h);
C = [0 0 0 1 0];
end
function r = eqres(z,p)
r = plant(z,0,p); r(3) = z(4)-p.Pref;
end
function dx = plant(x,u,p)
id=x(1); iq=x(2); d=x(3); pf=x(4); qf=x(5);
E  = p.E0 + p.nq*(p.Qref-qf);
vd = E*cos(d); vq = E*sin(d);
did = p.wb/p.X*(vd - p.Vg - p.R*id + p.X*iq);
diq = p.wb/p.X*(vq - p.R*iq - p.X*id);
pe = vd*id + vq*iq; qe = vq*id - vd*iq;
dx = [did; diq; p.mp*u; p.wf*(pe-pf); p.wf*(qe-qf)];
end
