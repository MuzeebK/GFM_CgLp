function [d, nres] = cep_sim(scr, cp, ev, T, dec, dslip)
%CEP_SIM  Runs gfm_cglp_cep.slx for one case.
%   d columns: t p w delta |i| xr q E pf nres  (decimation dec x 20 us)
%   dslip: the run stops when |delta| exceeds dslip (default: never).
if nargin < 5 || isempty(dec),   dec = 25;    end
if nargin < 6 || isempty(dslip), dslip = 1e9; end
p = cep_params(scr);
[~,~,~,x0] = cep_linear(scr, ev.P0);
v = {'wb',p.wb; 'Xl',p.X; 'Rl',p.R; 'i0',[x0(1); x0(2)]; 'th0',x0(3); ...
     'Q0',x0(5); 'I0',hypot(x0(1),x0(2)); 'cp',cp; 'scr',scr; ...
     'P0',ev.P0; 'P1',ev.P1; 'tstep',ev.tstep; 'Vf',ev.Vf; 'tf0',ev.tf0; ...
     'tf1',ev.tf1; 'phi',ev.phi; 'tj',ev.tj; 'Vn',ev.Vn; 'Ts',p.Ts; ...
     'Tsim',T; 'dec',dec; 'dslip',dslip};
for k = 1:size(v,1), assignin('base', v{k,1}, v{k,2}); end
out = sim('gfm_cglp_cep');
d = out.simlog; nres = d(end,10);
end
