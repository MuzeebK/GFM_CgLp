function ev = cep_ev(varargin)
%CEP_EV  Event description for one simulation (name/value pairs).
%   P0, P1, tstep : power-reference step;  Vf, tf0, tf1 : voltage dip;
%   phi, tj : grid phase jump;  Vn : negative-sequence voltage (pu).
ev = struct('P0',0.8,'P1',0.8,'tstep',1e9,'Vf',1,'tf0',1e9,'tf1',1e9, ...
            'phi',0,'tj',1e9,'Vn',0);
for k = 1:2:numel(varargin), ev.(varargin{k}) = varargin{k+1}; end
end
